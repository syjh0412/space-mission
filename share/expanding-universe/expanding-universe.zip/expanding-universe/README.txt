팽창하는 우주 탐구실 - 내 깃허브에 올리기 (재미있는 과학수업 만들기 공유용)

들어 있는 파일
  index.html  : 탐구실 본체 (학생 화면 + 선생님 화면)
  setup.html  : 학생 기록을 내 구글 시트에 모으는 설정 안내
  Code.gs     : 구글 시트(Apps Script)에 붙여 넣을 코드

올리는 순서
  1. github.com 가입 후 로그인
  2. 오른쪽 위 [+] → New repository
     - Repository name: 예) expanding-universe
     - Public 선택 → Create repository
  3. 새 저장소 화면에서 "uploading an existing file" 링크(또는 Add file → Upload files)
     - 압축을 푼 세 파일(index.html, setup.html, Code.gs)을 끌어다 놓기 → Commit changes
  4. Settings → Pages → Branch: main, 폴더: / (root) → Save
  5. 1~2분 뒤 https://내아이디.github.io/expanding-universe/ 로 열림

학생 기록을 모으려면
  내 주소 뒤에 setup.html 을 붙여 열고(https://내아이디.github.io/expanding-universe/setup.html)
  안내대로 구글 시트를 연결하면 학생용·선생님용 링크가 만들어져요.

내용을 고치려면
  저장소에서 index.html → 연필(Edit) → 고친 뒤 Commit changes. 1~2분 뒤 반영돼요.
